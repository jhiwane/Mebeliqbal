import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  ShoppingBag, Search, ArrowLeft, Plus, Minus, X, 
  Maximize2, CheckCircle2, Ban, Infinity as InfinityIcon,
  Database, Power, Edit, Trash2, Key, Gem,
  ChevronLeft, ChevronRight, CloudUpload,
  ArrowDown
} from 'lucide-react';

// ============================================================================
// 1. IMPORT FIREBASE (Pastikan sudah: npm install firebase)
// ============================================================================
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, onAuthStateChanged, signInWithCustomToken, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { getFirestore, collection, onSnapshot, doc, setDoc, deleteDoc } from 'firebase/firestore';

// ============================================================================
// 2. KONFIGURASI FIREBASE ANDA
// PENTING: Ganti tulisan "YOUR_..." ini dengan kode asli dari Firebase Console Anda!
// Jika tidak diganti, layar bisa jadi blank putih!
// ============================================================================
const localFirebaseConfig = {
  apiKey: "AIzaSyB5IawgYb126vy-WMt0Jdj6lxuBc0FcPZI",
  authDomain: "casa-curva.firebaseapp.com",
  projectId: "casa-curva",
  storageBucket: "casa-curva.firebasestorage.app",
  messagingSenderId: "51676281261",
  appId: "1:51676281261:web:409964689d5913b9230924",
  measurementId: "G-6PF06MXZK8"
};

const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : localFirebaseConfig;
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const appId = typeof __app_id !== 'undefined' ? __app_id : 'casacurva-local';
const productsPath = typeof __app_id !== 'undefined' ? `artifacts/${appId}/public/data/products` : `products`;


// --- TEMA WARNA & HELPER ---
const formatRupiah = (num) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(num);

const playPremiumSound = () => {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const playNote = (freq, timeOffset) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = 'sine'; osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, ctx.currentTime + timeOffset);
      gain.gain.linearRampToValueAtTime(0.1, ctx.currentTime + timeOffset + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + timeOffset + 0.6);
      osc.start(ctx.currentTime + timeOffset); osc.stop(ctx.currentTime + timeOffset + 0.6);
    };
    playNote(523.25, 0); playNote(659.25, 0.04); playNote(1046.50, 0.08);
  } catch (e) { }
};

// ============================================================================
// KOMPONEN: SMART IMAGE CAROUSEL
// ============================================================================
const SmartImageCarousel = ({ images, onImageClick, className = "" }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loadedImages, setLoadedImages] = useState({});
  const [isVisible, setIsVisible] = useState(false);
  const containerRef = useRef(null);

  const safeImages = images && images.length > 0 ? images : ["https://via.placeholder.com/800?text=Casa+Curva"];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setIsVisible(entry.isIntersecting),
      { threshold: 0.1 }
    );
    if (containerRef.current) observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible || safeImages.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % safeImages.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [isVisible, safeImages.length]);

  return (
    <div 
      ref={containerRef} 
      className={`relative overflow-hidden bg-[#F4EFE6] cursor-pointer group ${className}`} 
      onClick={() => onImageClick && onImageClick(safeImages, currentIndex)}
    >
      {safeImages.map((src, index) => (
        <div 
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
        >
          {!loadedImages[index] && (
            <div className="absolute inset-0 animate-pulse bg-gray-300"></div>
          )}
          <img
            src={src}
            alt={`Tampilan ${index + 1}`}
            loading="lazy"
            onLoad={() => setLoadedImages(prev => ({...prev, [index]: true}))}
            className={`w-full h-full object-cover transition-transform duration-[2s] ${index === currentIndex ? 'scale-105' : 'scale-100'}`}
          />
        </div>
      ))}
      
      {safeImages.length > 1 && (
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 z-20">
          {safeImages.map((_, idx) => (
            <div key={idx} className={`w-2 h-2 rounded-full transition-all duration-300 ${idx === currentIndex ? 'bg-[#D4AF37] w-4' : 'bg-white/50'}`} />
          ))}
        </div>
      )}
    </div>
  );
};


// ============================================================================
// KOMPONEN UTAMA (APP)
// ============================================================================
export default function App() {
  const [view, setView] = useState('home');
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Semua");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [detailQty, setDetailQty] = useState(1);
  const [lightbox, setLightbox] = useState({ isOpen: false, images: [], currentIndex: 0 });

  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [adminError, setAdminError] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const clickCount = useRef(0);
  const clickTimer = useRef(null);

  const [formData, setFormData] = useState({
    name: '', category: 'Sofa', price: '', qty: '', unlimited: false, description: '', images: ''
  });

  // TEKS HERO DINAMIS
  const [heroPhrase, setHeroPhrase] = useState("Elegan");
  const [isAnimating, setIsAnimating] = useState(false);
  const phrases = useMemo(() => ["Elegan", "Fungsional", "Presisi", "Berkelas", "Modern"], []);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setHeroPhrase(prev => {
          const currentIndex = phrases.indexOf(prev);
          return phrases[(currentIndex + 1) % phrases.length];
        });
        setIsAnimating(false);
      }, 500);
    }, 3500);
    return () => clearInterval(interval);
  }, [phrases]);

  // FITUR KEAMANAN (Dinonaktifkan sementara agar bisa lihat pesan error jika ada)
  useEffect(() => {
    /*
    const handleContextMenu = (e) => e.preventDefault();
    const handleKeyDown = (e) => {
      if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) || (e.ctrlKey && e.key === 'U')) {
        e.preventDefault();
      }
    };
    console.clear();
    console.log("%cTahan dulu!", "color: #D4AF37; background: #162A20; font-size: 40px; font-weight: bold; padding: 10px 20px; border-radius: 10px;");
    
    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
    */
  }, []);

  // FIREBASE INIT
  useEffect(() => {
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (err) { console.error("Firebase Auth Error:", err); }
    };
    initAuth();

    const unsubscribeAuth = onAuthStateChanged(auth, setUser);
    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (!user) return;
    const q = collection(db, productsPath);
    const unsubscribeData = onSnapshot(q, 
      (snapshot) => {
        const items = [];
        snapshot.forEach((doc) => items.push({ id: doc.id, ...doc.data() }));
        setProducts(items);
        setIsLoading(false);
      }, 
      (err) => {
        console.error("Firebase Snapshot Error:", err);
        setIsLoading(false);
      }
    );
    return () => unsubscribeData();
  }, [user]);

  useEffect(() => { setCart(JSON.parse(localStorage.getItem('casacurva_cart')) || []); }, []);
  useEffect(() => { localStorage.setItem('casacurva_cart', JSON.stringify(cart)); }, [cart]);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchName = p.name.toLowerCase().includes(search.toLowerCase());
      const matchCat = category === 'Semua' || p.category === category;
      return matchName && matchCat;
    });
  }, [products, search, category]);

  const cartTotalQty = cart.reduce((sum, item) => sum + item.qty, 0);

  // ACTIONS
  const handleLogoClick = () => {
    clickCount.current += 1;
    if (clickTimer.current) clearTimeout(clickTimer.current);
    if (clickCount.current >= 5) {
      clickCount.current = 0;
      setAdminEmail(""); setAdminPassword(""); setAdminError(false); setShowAdminLogin(true);
    } else {
      clickTimer.current = setTimeout(() => { clickCount.current = 0; }, 2000);
    }
  };

  const handleAdminLogin = async (e) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setAdminError(false);
    try {
      await signInWithEmailAndPassword(auth, adminEmail, adminPassword);
      setShowAdminLogin(false); setView('admin'); setAdminEmail(""); setAdminPassword(""); window.scrollTo(0,0);
    } catch (error) {
      console.error("Login Error:", error); setAdminError(true);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleAdminLogout = async () => {
    try {
      await signOut(auth);
      await signInAnonymously(auth);
      setView('home'); window.scrollTo(0,0);
    } catch (error) { console.error("Logout Error:", error); }
  };

  const openDetail = (product) => {
    setSelectedProduct(product); setDetailQty(1); setView('product');
    window.scrollTo({top: 0, behavior: 'smooth'});
  };

  const addToCart = (product, qtyToAdd) => {
    setCart(prev => {
      const exist = prev.find(i => i.id === product.id);
      if (exist) {
        if (!product.unlimited && exist.qty + qtyToAdd > product.qty) {
          alert(`Maaf, sisa stok maksimal adalah ${product.qty} unit.`); return prev;
        }
        return prev.map(i => i.id === product.id ? { ...i, qty: i.qty + qtyToAdd } : i);
      }
      return [...prev, { ...product, qty: qtyToAdd }];
    });
    playPremiumSound(); setView('home');
  };

  const removeFromCart = (id) => setCart(prev => prev.filter(i => i.id !== id));

  const checkoutWA = () => {
    let msg = "Halo Tim Casa Curva, saya tertarik dengan pesanan berikut:\n\n";
    cart.forEach(item => { msg += `🛋️ *${item.name}*\n   💰 ${formatRupiah(item.price)} x ${item.qty} unit\n\n`; });
    msg += "Mohon info ketersediaan & pengiriman. Terima kasih!";
    window.open(`https://wa.me/6285168182585?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleSaveProductToFirebase = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const imageArray = formData.images.split(',').map(s => {
        let path = s.trim();
        if(path && !path.startsWith('http') && !path.startsWith('assets/')) path = 'assets/' + path;
        return path;
      }).filter(p => p);

      const newProduct = {
        name: formData.name, category: formData.category, price: parseInt(formData.price) || 0,
        unlimited: formData.unlimited, qty: formData.unlimited ? -1 : parseInt(formData.qty) || 0,
        description: formData.description, images: imageArray.length > 0 ? imageArray : ["assets/default.jpg"]
      };

      const docId = editingId ? editingId : `prod_${Date.now()}`;
      await setDoc(doc(db, productsPath, docId), newProduct);

      setFormData({ name: '', category: 'Sofa', price: '', qty: '', unlimited: false, description: '', images: '' });
      setEditingId(null);
    } catch (error) {
      console.error("Error:", error); alert("Terjadi kesalahan saat menyimpan ke Database!");
    } finally { setIsSaving(false); }
  };

  const editProduct = (product) => {
    setEditingId(product.id);
    setFormData({
      name: product.name, category: product.category || 'Sofa', price: product.price,
      unlimited: product.unlimited, qty: product.qty === -1 ? '' : product.qty,
      description: product.description, images: (product.images || []).map(img => img.replace('assets/', '')).join(', ')
    });
    window.scrollTo({top: 0, behavior: 'smooth'});
  };

  const deleteProductFromFirebase = async (id) => {
    if(window.confirm('Yakin ingin menghapus produk ini secara permanen dari Database?')) {
      try { await deleteDoc(doc(db, productsPath, id)); } 
      catch (error) { console.error("Error:", error); alert("Gagal menghapus!"); }
    }
  };

  const openLightboxGallery = (images, index) => setLightbox({ isOpen: true, images: images, currentIndex: index });
  const closeLightbox = () => setLightbox({ ...lightbox, isOpen: false });
  const lightboxNext = (e) => { e.stopPropagation(); setLightbox(prev => ({ ...prev, currentIndex: (prev.currentIndex + 1) % prev.images.length })); };
  const lightboxPrev = (e) => { e.stopPropagation(); setLightbox(prev => ({ ...prev, currentIndex: prev.currentIndex === 0 ? prev.images.length - 1 : prev.currentIndex - 1 })); };


  return (
    <div className="min-h-screen bg-[#FDFBF7] font-sans text-gray-800 antialiased selection:bg-[#D4AF37] selection:text-white">
      
      {/* --- NAVBAR --- */}
      {view !== 'admin' && (
        <nav className="fixed w-full top-0 z-40 bg-[#162A20]/95 backdrop-blur-md border-b border-[#D4AF37]/20 transition-all duration-300">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            
            <div className="flex items-center gap-4 cursor-pointer select-none group" onClick={handleLogoClick}>
              <div className="w-12 h-12 rounded-full overflow-hidden border border-[#D4AF37]/50 bg-[#162A20] relative transition-all duration-500 group-hover:shadow-[0_0_15px_rgba(212,175,55,0.4)] group-hover:scale-105 shrink-0 flex items-center justify-center">
                 <img 
                    src="/assets/logo.webp" 
                    alt="Casa Curva Logo" 
                    className="w-full h-full object-cover object-[center_20%]" 
                    onError={(e) => { e.target.style.display='none'; e.target.nextSibling.style.display='flex'; }}
                 />
                 <div className="hidden w-full h-full items-center justify-center text-[#D4AF37] font-serif font-bold text-lg">CC</div>
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-2xl font-bold text-white tracking-wide leading-none">Casa<span className="text-[#D4AF37] italic">Curva</span></span>
                <span className="text-[9px] text-[#D4AF37]/80 uppercase tracking-[0.2em] mt-1 font-medium">Sofa & Cabinet Studio</span>
              </div>
            </div>

            <button onClick={() => setView('cart')} className="relative p-2 text-[#F4EFE6] hover:text-[#D4AF37] transition-colors duration-300">
              <ShoppingBag className="w-6 h-6" />
              {cartTotalQty > 0 && (
                <span className="absolute top-0 right-0 -mt-1 -mr-1 bg-[#D4AF37] text-[#162A20] font-bold text-[10px] w-5 h-5 rounded-full flex items-center justify-center shadow-lg border border-[#162A20] animate-bounce">
                  {cartTotalQty}
                </span>
              )}
            </button>
          </div>
        </nav>
      )}

      {/* --- LIGHTBOX MODAL (GALLERY) --- */}
      {lightbox.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-10 bg-black/95 backdrop-blur-sm transition-opacity duration-300" onClick={closeLightbox}>
          <button className="absolute top-6 right-6 text-white/50 hover:text-white z-10 w-12 h-12 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-all"><X className="w-6 h-6" /></button>
          {lightbox.images.length > 1 && (<button onClick={lightboxPrev} className="absolute left-4 md:left-10 text-white/50 hover:text-white z-10 w-12 h-12 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-all"><ChevronLeft className="w-8 h-8" /></button>)}
          <img src={lightbox.images[lightbox.currentIndex]} className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl animate-[scaleUp_0.3s_ease-out]" alt="Zoomed" onClick={(e) => e.stopPropagation()} />
          {lightbox.images.length > 1 && (<button onClick={lightboxNext} className="absolute right-4 md:right-10 text-white/50 hover:text-white z-10 w-12 h-12 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-all"><ChevronRight className="w-8 h-8" /></button>)}
          {lightbox.images.length > 1 && (
            <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-2 z-20">
              {lightbox.images.map((_, idx) => (<div key={idx} className={`w-2 h-2 rounded-full transition-all duration-300 ${idx === lightbox.currentIndex ? 'bg-[#D4AF37] w-4' : 'bg-white/50'}`} />))}
            </div>
          )}
        </div>
      )}

      {/* --- ADMIN LOGIN MODAL --- */}
      {showAdminLogin && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-[#162A20]/95 backdrop-blur-md">
          <div className="bg-white rounded-[2rem] p-8 max-w-md w-full relative shadow-2xl animate-[scaleUp_0.3s_ease-out]">
            <button onClick={() => setShowAdminLogin(false)} className="absolute top-5 right-5 text-gray-400 hover:bg-gray-100 rounded-full p-2"><X className="w-5 h-5" /></button>
            <div className="text-center mb-8 mt-4">
              <div className="w-16 h-16 bg-[#F4EFE6] rounded-full flex items-center justify-center mx-auto mb-4 border border-[#D4AF37]/30 text-[#D4AF37]"><Key className="w-8 h-8" /></div>
              <h2 className="text-2xl font-serif text-[#162A20] font-bold">Ruang Kerja Admin</h2>
            </div>
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <input 
                  type="email" placeholder="Email Admin" required
                  value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#D4AF37] outline-none text-center font-medium mb-4" 
                />
                <input 
                  type="password" placeholder="Kata Sandi Rahasia" required
                  value={adminPassword} onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#D4AF37] outline-none text-center tracking-widest font-mono" 
                />
                {adminError && <p className="text-red-500 text-sm mt-3 text-center font-medium bg-red-50 py-2 rounded-lg border border-red-100">Email atau Sandi salah!</p>}
              </div>
              <button type="submit" disabled={isLoggingIn} className={`w-full text-[#D4AF37] py-4 rounded-xl font-bold transition-colors shadow-lg ${isLoggingIn ? 'bg-gray-400 cursor-not-allowed text-white' : 'bg-[#162A20] hover:bg-[#0c1711]'}`}>
                {isLoggingIn ? 'Memverifikasi...' : 'Buka Akses'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ================= VIEW: HOME ================= */}
      {view === 'home' && (
        <div className="pt-20 animate-[fadeIn_0.5s_ease-out]">
          <div className="relative h-[70vh] min-h-[500px] bg-[#162A20] overflow-hidden">
            <img src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=2000&q=80" alt="Hero" className="absolute inset-0 w-full h-full object-cover opacity-30 mix-blend-luminosity scale-105 transition-transform duration-[20s] hover:scale-100" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#162A20] via-[#162A20]/80 to-transparent"></div>
            <div className="relative h-full max-w-7xl mx-auto px-4 flex flex-col justify-center items-center text-center">
              <span className="text-[#D4AF37] text-sm font-semibold tracking-widest uppercase mb-4 animate-[pulseSoft_2s_infinite]">casacurva.id</span>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-white mb-6 leading-tight flex flex-col items-center gap-2" style={{ textWrap: 'balance' }}>
                <span>Sofa & Cabinet Studio</span>
                <span className={`text-[#D4AF37] italic transition-all duration-500 ${isAnimating ? 'opacity-0 -translate-y-2' : 'opacity-100 translate-y-0'}`}>{heroPhrase}</span>
              </h1>
              <p className="text-[#F4EFE6]/80 max-w-2xl text-lg md:text-xl font-light mb-10 leading-relaxed text-center" style={{ textWrap: 'balance' }}>
                Temukan koleksi sofa, buffet, dan nakas yang menghadirkan sentuhan elegan untuk ruang Anda, jelajahi katalog kami dan temukan desain yang paling sesuai dengan gaya Anda.
              </p>
              <button onClick={() => document.getElementById('katalog-section').scrollIntoView({behavior:'smooth'})} className="group bg-[#D4AF37] text-[#162A20] px-8 py-4 rounded-full font-semibold text-sm uppercase tracking-wider hover:bg-white transition-all duration-300 shadow-[0_10px_30px_rgba(212,175,55,0.3)] flex items-center gap-3 hover:-translate-y-1">
                Jelajahi Koleksi <ArrowDown className="w-4 h-4 group-hover:animate-bounce" />
              </button>
            </div>
          </div>

          <div id="katalog-section" className="bg-white border-b border-gray-100 sticky top-20 z-30 shadow-sm transition-all duration-300">
            <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 hide-scrollbar">
                {['Semua', 'Sofa', 'Bench', 'Buffet', 'Nakas'].map(cat => (
                  <button 
                    key={cat} onClick={() => setCategory(cat)}
                    className={`shrink-0 px-5 py-2 rounded-full text-sm transition-colors ${category === cat ? 'bg-[#162A20] text-[#D4AF37] font-bold' : 'bg-[#F4EFE6] text-gray-600 font-medium hover:bg-[#D4AF37] hover:text-white'}`}
                  >{cat}</button>
                ))}
              </div>
              <div className="relative w-full md:w-72">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input 
                  type="text" placeholder="Cari karya impian..." 
                  value={search} onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-[#F4EFE6] focus:bg-white border border-transparent focus:border-[#D4AF37]/50 rounded-full text-sm outline-none transition-all shadow-inner" 
                />
              </div>
            </div>
          </div>

          <div className="max-w-7xl mx-auto px-4 py-16">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20 text-[#D4AF37]">
                <div className="w-12 h-12 border-4 border-[#D4AF37]/30 border-t-[#D4AF37] rounded-full animate-spin mb-4"></div>
                <p className="font-serif text-[#162A20] font-medium">Menghubungkan ke Database Cloud...</p>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center text-gray-400 py-24"><Ban className="w-16 h-16 mx-auto mb-4 text-[#D4AF37]/50" /><h3 className="text-2xl font-serif text-[#162A20]">Koleksi Tidak Ditemukan</h3></div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
                {filteredProducts.map((p) => (
                  <div key={p.id} className="bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 cursor-pointer group" onClick={() => openDetail(p)}>
                    <div className="relative h-72">
                      <SmartImageCarousel images={p.images} className="h-full w-full pointer-events-none" />
                      {!p.unlimited && p.qty <= 0 && (
                        <div className="absolute inset-0 bg-white/40 backdrop-blur-[2px] flex items-center justify-center z-30">
                          <span className="bg-[#0c1711] text-white px-6 py-2 rounded-full text-sm font-bold tracking-widest uppercase shadow-lg">Habis Terjual</span>
                        </div>
                      )}
                    </div>
                    <div className="p-8">
                      <span className="text-[10px] font-bold tracking-widest uppercase text-[#D4AF37] mb-2 block">{p.category}</span>
                      <h3 className="text-2xl font-bold font-serif text-[#162A20] mb-4 line-clamp-2">{p.name}</h3>
                      <div className="flex justify-between items-end">
                        <span className="text-gray-900 font-light text-xl">{formatRupiah(p.price)}</span>
                        <div className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center text-gray-400 group-hover:bg-[#162A20] group-hover:text-white transition-all">
                          <ArrowLeft className="rotate-135 w-5 h-5" style={{ transform: 'rotate(135deg)' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= VIEW: PRODUCT DETAIL ================= */}
      {view === 'product' && selectedProduct && (
        <div className="pt-20 bg-white min-h-screen pb-24 animate-[fadeIn_0.5s_ease-out]">
          <div className="bg-[#F4EFE6]/50 border-b border-gray-100">
            <div className="max-w-7xl mx-auto px-4 py-4">
              <button onClick={() => setView('home')} className="flex items-center gap-2 text-[#162A20] font-medium hover:text-[#D4AF37] transition-colors"><ArrowLeft className="w-5 h-5" /> Kembali</button>
            </div>
          </div>

          <div className="max-w-7xl mx-auto px-4 py-10 lg:py-16">
            <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
              <div className="w-full lg:w-1/2">
                <div className="sticky top-28">
                  <div className="rounded-[2rem] overflow-hidden shadow-xl relative group">
                    <SmartImageCarousel 
                      images={selectedProduct.images} 
                      onImageClick={openLightboxGallery}
                      className="aspect-square"
                    />
                    <div className="absolute top-4 right-4 bg-white/80 p-2 rounded-full pointer-events-none z-30 opacity-0 group-hover:opacity-100 transition-opacity text-[#162A20]"><Maximize2 className="w-5 h-5" /></div>
                  </div>
                </div>
              </div>

              <div className="w-full lg:w-1/2 flex flex-col justify-center">
                {selectedProduct.unlimited ? (
                  <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold bg-green-50 text-green-700 w-max mb-4"><CheckCircle2 className="w-4 h-4"/> Tersedia</span>
                ) : selectedProduct.qty > 0 ? (
                  <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold bg-green-50 text-green-700 w-max mb-4"><CheckCircle2 className="w-4 h-4"/> Tersedia {selectedProduct.qty} unit</span>
                ) : (
                  <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold bg-[#0c1711] text-[#D4AF37] w-max mb-4"><Ban className="w-4 h-4"/> Habis Terjual</span>
                )}

                <span className="text-[#D4AF37] font-semibold tracking-wider uppercase text-xs mb-3 block">{selectedProduct.category} Signature</span>
                <h1 className="text-4xl lg:text-5xl font-serif text-[#162A20] font-bold leading-tight mb-4" style={{ textWrap: 'balance' }}>{selectedProduct.name}</h1>
                <div className="text-3xl font-light text-gray-800 mb-8 pb-8 border-b border-gray-200">{formatRupiah(selectedProduct.price)}</div>

                <div className="prose prose-lg text-gray-600 mb-12">
                  <h3 className="text-xl font-serif text-[#162A20] font-bold mb-4 flex items-center gap-2">
                    {/* Inline SVG pengganti icon Quote */}
                    <svg className="text-[#D4AF37] opacity-50 w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.99c1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path></svg>
                    Cerita di Balik Karya Ini
                  </h3>
                  <p className="whitespace-pre-line leading-relaxed text-justify text-[15px]">{selectedProduct.description}</p>
                </div>

                {(selectedProduct.unlimited || selectedProduct.qty > 0) ? (
                  <div className="bg-[#F4EFE6]/50 p-6 md:p-8 rounded-3xl border border-[#D4AF37]/20">
                    <p className="text-sm text-gray-500 font-medium mb-4 uppercase tracking-wider">Tambahkan ke ruang Anda</p>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="flex items-center bg-white border border-gray-200 rounded-full h-14 overflow-hidden w-full sm:w-40 shadow-sm shrink-0">
                        <button onClick={() => setDetailQty(Math.max(1, detailQty - 1))} className="flex-1 h-full flex items-center justify-center text-gray-400 hover:text-[#162A20] hover:bg-gray-50"><Minus className="w-4 h-4" /></button>
                        <span className="w-12 text-center font-bold text-xl text-[#162A20]">{detailQty}</span>
                        <button onClick={() => setDetailQty((selectedProduct.unlimited || detailQty < selectedProduct.qty) ? detailQty + 1 : detailQty)} className="flex-1 h-full flex items-center justify-center text-gray-400 hover:text-[#162A20] hover:bg-gray-50"><Plus className="w-4 h-4" /></button>
                      </div>
                      <button onClick={() => addToCart(selectedProduct, detailQty)} className="flex-grow bg-[#162A20] text-white h-14 rounded-full font-bold flex items-center justify-center gap-3 hover:bg-[#D4AF37] transition-all shadow-lg hover:-translate-y-1">
                        <ShoppingBag className="w-5 h-5" /> Masukkan Keranjang
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-gray-100 p-6 rounded-3xl text-center border border-gray-200">
                    <h4 className="font-bold text-gray-700">Koleksi Ini Sedang Habis</h4>
                    <p className="text-sm text-gray-500 mt-1">Silakan hubungi kami untuk informasi pemesanan ulang.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= VIEW: CART ================= */}
      {view === 'cart' && (
        <div className="pt-20 bg-[#F4EFE6]/30 min-h-screen pb-24 animate-[fadeIn_0.5s_ease-out]">
          <div className="bg-[#162A20] pt-10 pb-20">
            <div className="max-w-5xl mx-auto px-4">
              <button onClick={() => setView('home')} className="text-[#D4AF37] hover:text-white flex items-center gap-2 mb-6"><ArrowLeft className="w-5 h-5" /> Lanjut Jelajahi</button>
              <h2 className="text-4xl font-serif text-white">Keranjang <span className="text-[#D4AF37] italic">Impian Anda</span></h2>
            </div>
          </div>
          <div className="max-w-5xl mx-auto px-4 -mt-10">
            {cart.length === 0 ? (
              <div className="bg-white rounded-3xl p-16 text-center shadow-xl border border-gray-100">
                <div className="w-24 h-24 bg-[#F4EFE6] rounded-full flex items-center justify-center mx-auto mb-6">
                  <ShoppingBag className="w-10 h-10 text-[#D4AF37]" />
                </div>
                <h3 className="text-2xl font-serif text-[#162A20] mb-3">Keranjang Masih Kosong</h3>
                <p className="text-gray-500 mb-8 max-w-md mx-auto">Ruang Anda menanti sentuhan magis. Mari temukan furnitur yang sempurna untuk melengkapinya.</p>
                <button onClick={() => setView('home')} className="mt-6 bg-[#162A20] text-white px-8 py-3 rounded-full font-medium hover:bg-[#D4AF37] transition-colors shadow-lg">Lihat Katalog Kami</button>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-4">
                  {cart.map((item, idx) => (
                    <div key={idx} className="bg-white p-5 rounded-3xl flex items-center gap-5 border border-gray-100 shadow-sm relative group">
                      <div className="w-24 h-24 rounded-2xl overflow-hidden bg-[#F4EFE6] shrink-0">
                        <img src={item.images?.[0] || 'https://via.placeholder.com/200'} className="w-full h-full object-cover" alt={item.name}/>
                      </div>
                      <div className="flex-grow pr-8">
                        <h4 className="font-bold font-serif text-[#162A20] text-lg mb-1">{item.name}</h4>
                        <p className="text-sm font-light text-gray-500 mb-2">{formatRupiah(item.price)} <span className="text-xs font-bold text-[#D4AF37] bg-[#D4AF37]/10 px-2 py-0.5 rounded ml-2">x {item.qty}</span></p>
                        <p className="font-medium text-[#D4AF37] text-lg">{formatRupiah(item.price * item.qty)}</p>
                      </div>
                      <button onClick={() => removeFromCart(item.id)} className="absolute right-6 w-10 h-10 bg-red-50 text-red-400 rounded-full flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
                    </div>
                  ))}
                </div>
                <div className="lg:col-span-1">
                  <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-100 sticky top-28">
                    <h3 className="font-serif text-2xl text-[#162A20] border-b pb-4 mb-6">Langkah Terakhir</h3>
                    <p className="text-gray-600 text-sm leading-relaxed mb-8 text-center bg-[#F4EFE6] p-4 rounded-xl"><Gem className="w-6 h-6 text-[#D4AF37] mx-auto mb-2" />Pesanan Anda akan diteruskan ke WhatsApp untuk konfirmasi pengiriman.</p>
                    <button onClick={checkoutWA} className="w-full bg-[#162A20] text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-[#25D366] transition-colors shadow-lg">Hubungi Tim Kami</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* FOOTER PUBLIK */}
      {view !== 'admin' && (
        <footer className="bg-[#0c1711] text-gray-400 py-16 border-t border-[#D4AF37]/10 mt-10">
            <div className="max-w-7xl mx-auto px-4 text-center">
                <span className="font-serif text-3xl font-bold text-white mb-4 block">Casa<span className="text-[#D4AF37] italic">Curva</span></span>
                <p className="text-sm mb-8 max-w-md mx-auto leading-relaxed text-gray-500">
                    Menghadirkan kenyamanan dan estetika paripurna ke dalam ruang Anda melalui koleksi sofa dan kabinet eksklusif bernilai seni tinggi.
                </p>
                <div className="flex justify-center gap-6 mb-8 text-[#D4AF37]/70">
                    <a href="#" className="hover:text-[#D4AF37] transition-colors">
                      {/* Inline SVG pengganti icon Instagram */}
                      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line></svg>
                    </a>
                    <a href="#" className="hover:text-[#D4AF37] transition-colors">
                      {/* Inline SVG pengganti icon MessageCircle */}
                      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"></path></svg>
                    </a>
                </div>
                <p className="text-xs tracking-wider uppercase text-gray-600">&copy; 2026 Casa Curva Studio. All rights reserved.</p>
            </div>
        </footer>
      )}

      {/* ================= VIEW: ADMIN FIREBASE DASHBOARD ================= */}
      {view === 'admin' && (
        <div className="bg-gray-50 min-h-screen pb-20">
          <header className="bg-[#162A20] text-white shadow-md">
            <div className="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <CloudUpload className="text-[#D4AF37] w-6 h-6" />
                <h1 className="font-bold font-serif text-lg tracking-wide">Live Database <span className="text-[#D4AF37]/70 text-sm font-sans font-normal ml-2">Casa Curva &bull; Firebase</span></h1>
              </div>
              <button onClick={handleAdminLogout} className="bg-red-500/10 text-red-200 hover:bg-red-500 hover:text-white px-4 py-1.5 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors"><Power className="w-4 h-4" /> Keluar</button>
            </div>
          </header>

          <div className="max-w-7xl mx-auto px-4 mt-8 grid grid-cols-1 xl:grid-cols-12 gap-8">
            <div className="xl:col-span-4">
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 sticky top-8">
                <h2 className="text-xl font-bold text-[#162A20] mb-6 border-b pb-4 flex items-center gap-2">
                   {editingId ? <Edit className="text-[#D4AF37] w-5 h-5"/> : <Database className="text-[#D4AF37] w-5 h-5"/>} 
                   {editingId ? 'Edit Produk Cloud' : 'Tambah ke Cloud'}
                </h2>
                <form onSubmit={handleSaveProductToFirebase} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Nama Furnitur</label>
                    <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#D4AF37] outline-none" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Kategori</label>
                      <select value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none">
                        <option>Sofa</option><option>Bench</option><option>Buffet</option><option>Nakas</option><option>Lainnya</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Harga (Rp)</label>
                      <input required type="number" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none" />
                    </div>
                  </div>
                  
                  <div className="bg-[#F4EFE6]/50 p-4 rounded-xl border border-gray-100">
                    <div className="flex items-center justify-between mb-3">
                      <label className="text-xs font-bold text-gray-500 uppercase">Stok Tersedia</label>
                      <label className="flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only" checked={formData.unlimited} onChange={e => setFormData({...formData, unlimited: e.target.checked, qty: ''})} />
                        <div className={`w-10 h-6 rounded-full relative transition-colors ${formData.unlimited ? 'bg-[#D4AF37]' : 'bg-gray-300'}`}><div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${formData.unlimited ? 'translate-x-5' : 'translate-x-1'}`}/></div>
                        <span className="ml-2 text-xs font-bold text-[#162A20]">Tak Terbatas</span>
                      </label>
                    </div>
                    <input type="number" disabled={formData.unlimited} required={!formData.unlimited} value={formData.qty} onChange={e => setFormData({...formData, qty: e.target.value})} placeholder="Misal: 5" className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl outline-none disabled:bg-gray-100" />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Deskripsi Lengkap</label>
                    <textarea required rows="3" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none resize-none" />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Nama File WebP / JPG (Pisahkan Koma)</label>
                    <input required type="text" value={formData.images} onChange={e => setFormData({...formData, images: e.target.value})} placeholder="contoh: foto1.webp, foto2.webp" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none font-mono text-sm text-[#162A20]" />
                    <p className="text-[10px] text-gray-400 mt-1">File akan otomatis dicarikan di dalam folder 'assets/'.</p>
                  </div>

                  <div className="flex gap-3 pt-2">
                    {editingId && (
                      <button type="button" onClick={() => {setEditingId(null); setFormData({name:'',category:'Sofa',price:'',qty:'',unlimited:false,description:'',images:''})}} className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-600 py-3 rounded-xl font-bold transition-colors">Batal</button>
                    )}
                    <button type="submit" disabled={isSaving} className={`flex-[2] text-white py-3 rounded-xl font-bold transition-colors flex items-center justify-center gap-2 ${isSaving ? 'bg-gray-400 cursor-not-allowed' : 'bg-[#162A20] hover:bg-[#0c1711]'}`}>
                       {isSaving ? 'Menyimpan...' : (editingId ? 'Simpan Perubahan' : 'Push ke Firebase')}
                    </button>
                  </div>
                </form>
              </div>
            </div>

            <div className="xl:col-span-8">
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-6 bg-gray-50 border-b flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-[#162A20] text-xl">Database Produk Live</h3>
                    <p className="text-sm text-gray-500">Total: {products.length} item aktif di Cloud</p>
                  </div>
                  <div className="text-xs font-mono bg-green-100 text-green-700 px-3 py-1 rounded-full flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Tersinkronisasi
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="text-xs uppercase text-gray-400 bg-white border-b">
                      <tr>
                        <th className="p-4 w-12">No</th>
                        <th className="p-4">Produk</th>
                        <th className="p-4">Harga</th>
                        <th className="p-4 text-center">Stok</th>
                        <th className="p-4 text-center">Aksi (Live)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((p, idx) => (
                        <tr key={p.id} className={`border-b ${editingId === p.id ? 'bg-[#D4AF37]/10' : 'hover:bg-gray-50'}`}>
                          <td className="p-4 text-center text-sm">{idx + 1}</td>
                          <td className="p-4">
                            <div className="font-bold text-[#162A20]">{p.name}</div>
                            <div className="text-[10px] text-gray-500">{p.category} | {p.images?.length || 0} Gambar</div>
                          </td>
                          <td className="p-4 text-sm font-medium">{formatRupiah(p.price)}</td>
                          <td className="p-4 text-center">
                            {p.unlimited ? <span className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold"><InfinityIcon className="w-3 h-3 inline"/></span> : <span className="bg-gray-100 px-2 py-1 rounded text-xs font-bold">{p.qty}</span>}
                          </td>
                          <td className="p-4 text-center flex justify-center gap-2">
                            <button onClick={() => editProduct(p)} className="p-2 text-blue-500 hover:bg-blue-50 rounded" title="Edit Data"><Edit className="w-4 h-4"/></button>
                            <button onClick={() => deleteProductFromFirebase(p.id)} className="p-2 text-red-500 hover:bg-red-50 rounded" title="Hapus dari Firebase"><Trash2 className="w-4 h-4"/></button>
                          </td>
                        </tr>
                      ))}
                      {products.length === 0 && !isLoading && <tr><td colSpan="5" className="text-center p-8 text-gray-400">Belum ada data di Database Firebase.</td></tr>}
                      {isLoading && <tr><td colSpan="5" className="text-center p-8 text-gray-400">Mengambil data dari Cloud...</td></tr>}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- CSS Animasi Tambahan --- */}
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes scaleUp { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        @keyframes pulseSoft { 0%, 100% { opacity: 1; } 50% { opacity: 0.8; } }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}} />
    </div>
  );
}